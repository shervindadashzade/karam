<?php

$host = 'localhost';
$username = 'shervin';
$password = 'Shervin1349';
$db_name = 'karam'

?>