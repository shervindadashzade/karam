let config = {
    url : 'http://karam.lan/back-end',
};

export default config;