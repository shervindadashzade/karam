![info](https://github.com/shervindadashzade/karam/blob/master/front-end/docs/info.jpg)

# Karam 
Karam is an underdevelopment Persian/Farsi ToDo web application.
I have started working on this open-source project to sharpen my technical skills, including pure JavaScript, EcmaScript, HTML5, CSS3, and I don't plan to utilize any framework.

# First Preview Of Project

To check the current version of this repository, please check out this demo and please let me know if you could open any issues:
[let's go](https://shervindadashzade.github.io/karam/front-end)

I would be happy to see your contributions or stars if you liked it.
