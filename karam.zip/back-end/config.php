<?php

$host = 'localhost';
$username = 'shervin';
$password = 'Shervin1349';


?>